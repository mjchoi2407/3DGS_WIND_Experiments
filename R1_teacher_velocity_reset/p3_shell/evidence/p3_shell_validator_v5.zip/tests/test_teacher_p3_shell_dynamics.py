import unittest

import numpy as np
from scipy.sparse.linalg import spsolve

from wind3dgs.teacher.p3_shell import P3Shell
from wind3dgs.teacher.p3_shell_dynamics import P3ShellStepper, ShellSolvePolicy, ShellStepFailed


class P3ShellDynamicsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model=P3Shell(4); cls.stepper=P3ShellStepper(cls.model)

    def test_zero_state_and_prescribed_rigid_acceleration(self):
        s=self.stepper; state=s.state()
        out,r=s.step(state,np.zeros_like(state.displacement_m),1/600)
        np.testing.assert_array_equal(out.displacement_m,state.displacement_m)
        self.assertEqual(r['energy_j'],0.)
        m=P3Shell(4,clamp=False); s=P3ShellStepper(m)
        velocity=np.tile([.12,-.02,.07],(len(m.xy),1)); acceleration=np.tile([.3,-.1,.2],(len(m.xy),1))
        force=m.mass@acceleration; state=s.state(velocity=velocity); dt=1/600
        out,r=s.step(state,force,dt)
        np.testing.assert_allclose(out.displacement_m,dt*velocity+.5*dt**2*acceleration,atol=1e-14)
        np.testing.assert_allclose(out.velocity_m_s,velocity+dt*acceleration,atol=1e-11)
        self.assertLess(abs(r['energy_balance_residual_j']),1e-16)

    def test_linear_limit_newmark_and_actual_residual(self):
        s=self.stepper; m=self.model; state=s.state()
        force=m.aerodynamic_force_displacement(state.displacement_m,state.velocity_m_s,[0.,.05,0.])['force_n']
        dt=1/6000; c=dt*dt/4; f=force[m.free].ravel()
        a0=spsolve(s.M,f); a1=spsolve(s.M+c*s.K,f-c*(s.K@a0))
        u=c*(a0+a1); v=dt/2*(a0+a1)
        out,r=s.step(state,force,dt)
        np.testing.assert_allclose(out.displacement_m[m.free].ravel(),u,rtol=2e-5,atol=2e-13)
        np.testing.assert_allclose(out.velocity_m_s[m.free].ravel(),v,rtol=2e-5,atol=2e-9)
        actual_a=2*out.velocity_m_s/dt
        actual_a[m.free]-=a0.reshape(-1,3)
        residual=m.mass@actual_a-m.evaluate_displacement(out.displacement_m)['force_n']-force
        self.assertLessEqual(np.linalg.norm(residual[m.free]),r['force_limit_n']*1.01)
        np.testing.assert_allclose(residual[~m.free],r['constraint_reaction_n'][~m.free],atol=1e-14)

    def test_reset_preserves_shape_removes_consistent_kinetic_energy(self):
        s=self.stepper; m=self.model; u=np.zeros_like(m.rest_positions)
        u[:,1]=.2*(m.xy[:,0]-.25)**2
        v=np.random.default_rng(600).normal(size=u.shape)*.01; v[~m.free]=0
        original=s.state(displacement=u,velocity=v,time_s=.7)
        reset,removed=s.reset_velocity(original)
        np.testing.assert_array_equal(original.displacement_m,reset.displacement_m)
        np.testing.assert_array_equal(reset.velocity_m_s,np.zeros_like(v))
        self.assertEqual(reset.time_s,.7)
        self.assertAlmostEqual(removed,.5*np.sum(v*(m.mass@v)),places=16)
        self.assertGreater(removed,0)

    def test_bent_equilibrium_and_failure_preserves_input(self):
        s=self.stepper; m=self.model; u=np.zeros_like(m.rest_positions)
        t=m.xy[:,0]-.25; curvature=1.2
        u[:,0]=np.sin(curvature*t)/curvature-t
        u[:,1]=(1-np.cos(curvature*t))/curvature
        state=s.state(displacement=u)
        balancing=-m.evaluate_displacement(u)['force_n']
        out,r=s.step(state,balancing,1/600)
        np.testing.assert_array_equal(out.displacement_m,u)
        np.testing.assert_array_equal(out.velocity_m_s,np.zeros_like(u))
        strict=P3ShellStepper(m,policy=ShellSolvePolicy(max_newton=1))
        original=state.displacement_m.copy()
        with self.assertRaises(ShellStepFailed) as caught:
            strict.step(state,np.zeros_like(u),.01)
        self.assertGreater(len(caught.exception.attempts),0)
        np.testing.assert_array_equal(state.displacement_m,original)


if __name__ == '__main__': unittest.main()
